package bi;

import java.util.Scanner;

public class Tab {

    private int[] myArray;

    public Tab(String[] args) {
        myArray = new int[args.length];

        for (int i = 0; i < args.length; i++) {
            try {
                myArray[i] = Integer.parseInt(args[i]);
            } catch (NumberFormatException e) {
                System.out.println("Error : " + args[i] + "is not an number.");
                myArray[i] = 0;
            }
        }
    }

    public void printArray() {
        System.out.print("Tableau : ");
        for (int nombre : myArray) {
            System.out.print(nombre + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Tab myArrayObj = new Tab(args);
        myArrayObj.printArray();

        Scanner myObj = new Scanner(System.in);
        System.out.println("Lineary or Binary search ?");

        String search = myObj.nextLine();

        if (search.equals("Binary")) {  // Utilisation de .equals pour comparer les chaînes
            myArrayObj.binarySearch();
        } else if (search.equals("Lineary")) {
            myArrayObj.linearySearch();
        } else {
            System.out.println("Option not available");
        }

        myObj.close();
    }

    public void linearySearch() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an number to found : ");

        int number = scanner.nextInt();

        for (int i = 0; i < myArray.length; i++) {
            if (myArray[i] == number) {
                System.out.println("Number found at the index " + i + ".");
                scanner.close();
                return;
            }
        }

        System.out.println("Number not found.");
        scanner.close();
    }

    public void binarySearch() {
        // Tri du tableau avant de faire la recherche binaire
        bubbleSort();

        System.out.print("Sorted list : ");
        printArray();  // Affiche le tableau trié

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an number to found : ");

        int number = scanner.nextInt();
        scanner.close();

        int result = binarySearchHelper(myArray, 0, myArray.length - 1, number);

        if (result != -1) {
            System.out.println("Number found at the index " + result + ".");
        } else {
            System.out.println("Number not found");
        }
    }

    private void bubbleSort() {
        int n = myArray.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (myArray[j] > myArray[j + 1]) {
                    // Échange des éléments
                    int temp = myArray[j];
                    myArray[j] = myArray[j + 1];
                    myArray[j + 1] = temp;
                }
            }
        }
    }

    private int binarySearchHelper(int[] tab, int f, int l, int val) {
        if (l >= f) {
            int mid = f + (l - f) / 2;

            if (tab[mid] == val) {
                return mid;
            }

            if (tab[mid] > val) {
                // Recherche dans la moitié gauche
                return binarySearchHelper(tab, f, mid - 1, val);
            } else {
                // Recherche dans la moitié droite
                return binarySearchHelper(tab, mid + 1, l, val);
            }
        }
        return -1;  // Valeur non trouvée
    }
}
